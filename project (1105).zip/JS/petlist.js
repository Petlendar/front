document.addEventListener('DOMContentLoaded', async function() {
    const petListContainer = document.getElementById('pet-list');
    const accessToken = localStorage.getItem('accessToken'); // 로컬 스토리지에서 토큰 가져오기
  
    if (!accessToken) {
      petListContainer.innerHTML = '<p>로그인이 필요합니다. 먼저 로그인해 주세요.</p>';
      return;
    }
  
    try {
      const response = await fetch('http://114.70.216.57/pet/api/pet', {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        }
      });
  
      const data = await response.json();
  
      if (data.result.resultCode === 200 && Array.isArray(data.body)) {
        petListContainer.innerHTML = ''; // 기존 목록 초기화
  
        data.body.forEach(pet => {
          const petItem = document.createElement('div');
          petItem.classList.add('pet-item');
  
          petItem.innerHTML = `
            <p><strong>이름:</strong> <a href="petDetail.html?petId=${pet.petId}">${pet.name}</a></p>
            <p><strong>카테고리:</strong> ${pet.category}</p>
            ${pet.petImage ? `<img src="${pet.petImage.imageUrl}" alt="${pet.name} 이미지" width="100">` : ''}
          `;
  
          petListContainer.appendChild(petItem);
        });
      } else {
        petListContainer.innerHTML = '<p>반려동물 목록을 불러오는 데 실패했습니다.</p>';
      }
    } catch (error) {
      console.error('반려동물 목록 조회 중 오류 발생:', error);
      petListContainer.innerHTML = '<p>오류 발생: 반려동물 목록을 불러올 수 없습니다.</p>';
    }
  });
  