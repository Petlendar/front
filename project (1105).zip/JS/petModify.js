document.addEventListener('DOMContentLoaded', async function() {
  const urlParams = new URLSearchParams(window.location.search);
  const petId = urlParams.get('petId');
  const accessToken = localStorage.getItem('accessToken');
  const responseMessage = document.getElementById('response-message');

  if (!accessToken) {
    document.body.innerHTML = '<p>로그인이 필요합니다. 먼저 로그인해 주세요.</p>';
    return;
  }

  if (!petId) {
    document.body.innerHTML = '<p>유효하지 않은 요청입니다. 반려동물 ID가 필요합니다.</p>';
    return;
  }

  document.getElementById('pet-modify-form').addEventListener('submit', async function(event) {
    event.preventDefault();

    const name = document.getElementById('name').value;
    const birth = document.getElementById('birth').value;
    const address = document.getElementById('address').value;

    const modifyData = {
      result: {
        resultCode: 0,
        resultMessage: "string",
        resultDescription: "string"
      },
      body: {
        petId: parseInt(petId),
        name: name,
        birth: birth,
        address: address
      }
    };

    try {
      const response = await fetch('http://114.70.216.57/pet/api/pet/update', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(modifyData)
      });

      const data = await response.json();

      if (data.result.resultCode === 200) {
        responseMessage.textContent = '반려동물 정보가 성공적으로 수정되었습니다!';
        responseMessage.style.color = 'green';
        responseMessage.style.display = 'block';
        setTimeout(() => {
          window.location.href = `petDetail.html?petId=${petId}`;
        }, 2000);
      } else {
        responseMessage.textContent = '반려동물 정보 수정 실패: ' + data.result.resultMessage;
        responseMessage.style.color = 'red';
        responseMessage.style.display = 'block';
      }
    } catch (error) {
      console.error('반려동물 정보 수정 중 오류 발생:', error);
      responseMessage.textContent = '오류 발생: 반려동물 정보를 수정할 수 없습니다.';
      responseMessage.style.color = 'red';
      responseMessage.style.display = 'block';
    }
  });
});
